// Simple Node for Queue
class Node<T>
{
    T data;
    Node<T> next;
    Node(T data)
    {
        this.data = data;
        this.next = null;
    }
}

// Custom Queue (FIFO)
class MyQueue<T>
{
    private Node<T> front, rear;

    public MyQueue()
    {
        this.front = this.rear = null;
    }

    public void add(T item)
    {
        Node<T> newNode = new Node<>(item);
        if (rear == null)
        {
            front = rear = newNode;
            return;
        }
        rear.next = newNode;
        rear = newNode;
    }

    public T poll()
    {
        if (front == null)
        {
            return null;
        }
        T item = front.data;
        front = front.next;
        if (front == null)
        {
            rear = null;
        }
        return item;
    }

    public T peek()
    {
        if (front == null)
        {
            return null;
        }
        return front.data;
    }

    public boolean isEmpty()
    {
        return front == null;
    }
}

class KeyValue<K, V>
{
    K key;
    V value;
    KeyValue<K, V> next;

    KeyValue(K key, V value)
    {
        this.key = key;
        this.value = value;
    }
}

class MyMap<K, V>
{
    private int SIZE = 16;
    private KeyValue<K, V>[] table;

    @SuppressWarnings("unchecked")
    public MyMap()
    {
        table = new KeyValue[SIZE];
    }

    private int hash(K key)
    {
        return Math.abs(key.hashCode()) % SIZE;
    }

    public void put(K key, V value)
    {
        int index = hash(key);
        KeyValue<K, V> newNode = new KeyValue<>(key, value);
        if (table[index] == null)
        {
            table[index] = newNode;
        }
        else
        {
            KeyValue<K, V> curr = table[index];
            while (true)
            {
                if (curr.key.equals(key))
                {
                    curr.value = value;
                    return;
                }
                if (curr.next == null)
                {
                    break;
                }
                curr = curr.next;
            }
            curr.next = newNode;
        }
    }

    public V get(K key)
    {
        int index = hash(key);
        KeyValue<K, V> curr = table[index];
        while (curr != null)
        {
            if (curr.key.equals(key))
            {
                return curr.value;
            }
            curr = curr.next;
        }
        return null;
    }
}

public class OrderProcessor implements Runnable
{
    private static final MyMap<Integer, Object> RES_LOCKS = new MyMap<>();
    private static final MyMap<Integer, MyQueue<OrderContext>> ORDER_QUEUES = new MyMap<>();

    private final OrderContext ctx;

    public OrderProcessor(OrderContext ctx)
    {
        this.ctx = ctx;
    }

    private static Object lockForRestaurant(int restaurantId)
    {
        Object lock = RES_LOCKS.get(restaurantId);
        if (lock == null)
        {
            lock = new Object();
            RES_LOCKS.put(restaurantId, lock);
        }
        return lock;
    }

    private static MyQueue<OrderContext> queueForRestaurant(int restaurantId)
    {
        MyQueue<OrderContext> q = ORDER_QUEUES.get(restaurantId);
        if (q == null)
        {
            q = new MyQueue<>();
            ORDER_QUEUES.put(restaurantId, q);
        }
        return q;
    }

    @Override
    public void run()
    {
        Object lock = lockForRestaurant(ctx.restaurantId);
        MyQueue<OrderContext> q = queueForRestaurant(ctx.restaurantId);
        q.add(ctx);

        synchronized (lock)
        {
            OrderContext head;
            while ((head = q.peek()) != ctx)
            {
                try
                {
                    lock.wait(250);
                }
                catch (InterruptedException ignored) {}
            }

            try
            {
                System.out.println("[Restaurant " + ctx.restaurantId + "] Preparing order #" + ctx.orderId + "...");
                Thread.sleep(Math.max(3000, ctx.etaMinutes * 500L));
                ctx.status = OrderStatus.OUT_FOR_DELIVERY;
                System.out.println("[Restaurant " + ctx.restaurantId + "] Order #" + ctx.orderId +
                        " is OUT FOR DELIVERY by " + ctx.deliveryPartnerName +
                        " Mobile No. " + ctx.deliveryPartnerPhone + " .");
                Thread.sleep(Math.max(3000, ctx.etaMinutes * 400L));
                ctx.status = OrderStatus.DELIVERED;
                System.out.println("[Restaurant " + ctx.restaurantId + "] Order #" + ctx.orderId + " DELIVERED. Enjoy your meal!\n");
            }
            catch (InterruptedException e)
            {
                System.out.println("Order thread interrupted: " + e.getMessage());
            }
            finally
            {
                q.poll();
                lock.notifyAll();
            }
        }
    }
}