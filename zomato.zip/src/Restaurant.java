import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Restaurant
{
    Scanner scanner = new Scanner(System.in);

    protected void WhattoDo(int id) throws Exception
    {
        try (Connection con = DB.get())
        {
            System.out.println("Your Menu List");
            try (PreparedStatement pst = con.prepareStatement("SELECT item_id, item_name, price FROM menu_item WHERE r_id=?"))
            {
                pst.setInt(1, id);
                try (ResultSet rs = pst.executeQuery())
                {
                    while (rs.next()) System.out.println(rs.getInt(1) + ") " + rs.getString(2) + "               " + rs.getDouble(3)+" Rs.");
                }
            }
            System.out.println("\n1) Add New Item  2) Update Item  3) Exit");
            System.out.print("Choice : ");
            int x = readInt();

            if (x == 1)
            {
                try (PreparedStatement pst1 = con.prepareStatement("INSERT INTO menu_item(item_name, price, r_id) VALUES (?,?,?)"))
                {
                    System.out.print("Enter New Item Name : ");
                    String name = scanner.next();
                    System.out.print("Enter New Item Price : ");
                    double price = scanner.nextDouble();
                    pst1.setString(1, name);
                    pst1.setDouble(2, price);
                    pst1.setInt(3, id);
                    int r = pst1.executeUpdate();
                    System.out.println(r > 0 ? "Item Inserted" : "Insertion Failed");
                }
            }
            else if (x == 2)
            {
                try (PreparedStatement pst2 = con.prepareStatement("UPDATE menu_item SET item_name=?, price=? WHERE item_id=? AND r_id=?"))
                {
                    System.out.print("Enter Item Id to Update: ");
                    int itemId = readInt();
                    System.out.print("Enter New Item Name : ");
                    String name = scanner.next();
                    System.out.print("Enter New Item Price : ");
                    double price = scanner.nextDouble();
                    pst2.setString(1, name);
                    pst2.setDouble(2, price);
                    pst2.setInt(3, itemId);
                    pst2.setInt(4, id);
                    int r1 = pst2.executeUpdate();
                    System.out.println(r1 > 0 ? "Item Updated" : "Update Failed");
                }
            }
            else
            {
                return;
            }
        }
    }

    private int readInt()
    {
        while (!scanner.hasNextInt())
        {
            System.out.print("Enter number: ");
            scanner.next();
        }
        return scanner.nextInt();
    }
}