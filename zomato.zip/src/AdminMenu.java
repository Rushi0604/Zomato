import java.sql.*;
import java.util.*;

public class AdminMenu
{

    Scanner sc = new Scanner(System.in);
    String password = "Admin@123";
    public void showMenu()throws SQLException
    {
        int c=0;
        while(true)
        {
            System.out.print("Enter Passkey: ");
            String key = sc.next();
            if(key.equals(password))
            {
                int ch;
                do
                {
                    System.out.println("\n===== Admin Menu =====");
                    System.out.println("1 Show Active Users");
                    System.out.println("2 Show Monthly History");
                    System.out.println("3 Remove Restaurant");
                    System.out.println("4 Remove Delivery Partner");
                    System.out.println("5 Back");
                    System.out.print("Choice: ");
                    ch = sc.nextInt();

                    switch (ch) {
                        case 1 -> showActiveUsers();
                        case 2 -> showMonthlyHistory();
                        case 3 -> removeRestaurant();
                        case 4 -> removeDeliveryPartner();
                        case 5 -> System.out.println("Returning...");
                        default -> System.out.println("Invalid Choice");
                    }
                }
                while (ch != 3);
            }
            else
            {
                System.out.println("Enter Valid Passkey");
            }
            c++;
            if(c==3)
            {
                System.out.println("0 For Back");
                int e = sc.nextInt();
                if(e==0)
                {
                    return;
                }
            }
        }
    }

    // Active users (users with the highest orders)
    private void showActiveUsers()
    {
        try (Connection con = DB.get();
             Statement st = con.createStatement())
        {

            String sql = "SELECT user_id,u_name, COUNT(*) as order_count " +
                    "FROM orders inner join user_details on orders.user_id = user_details.u_id GROUP BY user_id,u_name " +
                    "ORDER BY order_count DESC";

            ResultSet rs = st.executeQuery(sql);
            System.out.println("\nUser ID) User Name | Orders");
            while (rs.next())
            {
                System.out.println(rs.getInt("user_id")+") "+rs.getString("u_name") + " | " + rs.getInt("order_count"));
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    // Monthly History
    private void showMonthlyHistory()
    {
        try (Connection con = DB.get();
             Statement st = con.createStatement())
        {

            String sql = "SELECT restaurant_id,restaurantName, COUNT(*) as total_orders " +
                    "FROM orders inner join restaurant on orders.restaurant_id = restaurant.restaurantId " +
                    "WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH) " +
                    "GROUP BY restaurant_id,restaurantName";

            ResultSet rs = st.executeQuery(sql);
            System.out.println("\nRestaurant ID) Restaurant Name | Orders Last Month");
            while (rs.next())
            {
                System.out.println(rs.getInt("restaurant_id")+") "+rs.getString("restaurantName") + " | " + rs.getInt("total_orders"));
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    private void removeRestaurant()throws SQLException
    {
        Connection con = DB.get();
        String display = "SELECT * FROM Restaurant";
        Statement s = con.createStatement();
        ResultSet rs = s.executeQuery(display);
        while (rs.next())
        {
            System.out.println("Restaurant_ID: "+rs.getInt("restaurantId")+" "+"Restaurant Name: "+rs.getString("restaurantName"));
        }
        System.out.println();
        System.out.print("Enter Restaurant Id : ");
        int rid = sc.nextInt();
        String remove = "DELETE FROM restaurant WHERE restaurantId=?";
        PreparedStatement pst = con.prepareStatement(remove);
        pst.setInt(1,rid);
        int r = pst.executeUpdate();
        System.out.println(r>0?"Restaurant Removed":"Deletion Faild");
    }
    private void removeDeliveryPartner()throws SQLException
    {
        Connection con = DB.get();
        String display = "SELECT * FROM Deliverypartner_details";
        Statement s = con.createStatement();
        ResultSet rs = s.executeQuery(display);
        while (rs.next())
        {
            System.out.println("DeliveryPartner_Id: "+rs.getInt("dp_id")+" "+"DeliveryPartner Name: "+rs.getString("dp_name"));
        }
        System.out.println();
        System.out.print("Enter DeliveryPartner Id : ");
        int did = sc.nextInt();
        String remove = "DELETE FROM Deliverypartner_details WHERE dp_id=?";
        PreparedStatement pst = con.prepareStatement(remove);
        pst.setInt(1,did);
        int r = pst.executeUpdate();
        System.out.println(r>0?"DeliveryPartner Removed":"Deletion Faild");
    }
}
