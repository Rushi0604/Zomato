import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB
{
    public static final String URL = "jdbc:mysql://localhost:3306/zomato";
    public static final String USER = "root";
    public static final String PASS = "";

    public static Connection get() throws SQLException
    {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}