public class UserDetails
{
    String name;
    String password;
    String Email;
    String phoneNumber;
    String Address;

    public UserDetails(String name, String password, String email, String phoneNumber)
    {
        this.name = name;
        this.password = password;
        Email = email;
        this.phoneNumber = phoneNumber;
    }

    // getters/setters omitted for brevity
}