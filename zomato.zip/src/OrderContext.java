public class OrderContext
{
    int orderId;
    int restaurantId;
    int deliveryPartnerId;
    String deliveryPartnerName;
    long deliveryPartnerPhone;
    int etaMinutes;
    OrderStatus status = OrderStatus.PREPARING;
}