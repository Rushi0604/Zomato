import java.sql.*;
import java.util.*;

public class Login
{
    Scanner scanner = new Scanner(System.in);

    protected void Login() throws Exception
    {
        System.out.println("1) user\n2) hotel\n3) delivery partner");
        System.out.print("choice : ");
        int x = readInt();
        loginApp(x);
    }

    private int readInt()
    {
        while (!scanner.hasNextInt())
        {
            System.out.print("Enter number: ");
            scanner.next();
        }
        return scanner.nextInt();
    }

    void loginApp(int x) throws Exception
    {
        System.out.println("1) login with number\n2) login with email");
        System.out.print("Choice: ");
        int y = readInt();
        String password;
        int attempts = 0;

        switch (y)
        {
            case 1 ->
            {
                long number = checkNumber();
                while (true)
                {
                    System.out.print("Enter password: ");
                    password = scanner.next();
                    if (password.length() >= 6)
                    {
                        boolean ok = false;
                        try (Connection con = DB.get())
                        {
                            PreparedStatement pst; ResultSet rs;
                            if (x == 1)
                            {
                                pst = con.prepareStatement("SELECT u_id, u_name, u_password FROM user_details WHERE u_phoneNumber=?");
                                pst.setLong(1, number);
                                rs = pst.executeQuery();
                                if (rs.next() && rs.getString("u_password").equals(password))
                                {
                                    ok = true;
                                    int uid = rs.getInt("u_id");
                                    String uname = rs.getString("u_name");
                                    new User(uid, uname).menu();
                                }
                            }
                            else if (x == 2)
                            {
                                pst = con.prepareStatement("SELECT restaurantId, restaurantName, r_pass FROM restaurant WHERE restaurantPhone=?");
                                pst.setLong(1, number);
                                rs = pst.executeQuery();
                                if (rs.next() && rs.getString("r_pass").equals(password))
                                {
                                    ok = true;
                                    int rid = rs.getInt("restaurantId");
                                    new Restaurant().WhattoDo(rid);
                                }
                            }
                            else if (x == 3)
                            {
                                pst = con.prepareStatement("SELECT dp_id, dp_name, dp_password FROM deliverypartner_details WHERE dp_phoneNumber=?");
                                pst.setLong(1, number);
                                rs = pst.executeQuery();
                                if (rs.next() && rs.getString("dp_password").equals(password))
                                {
                                    ok = true;
                                    int dpid=rs.getInt("dp_id");
                                    String dpname= rs.getString("dp_name");
                                    dpDetails(dpid,dpname);
                                    //System.out.println("Login success. Welcome, " + rs.getString("dp_name") + ".");
                                }
                            }
                        }
                        if (ok)
                        {
                            break;
                        }
                        else
                        {
                            System.out.println("Invalid credentials. Try again.");
                        }
                    }
                    else
                    {
                        System.out.println("Password must be at least 6 characters.");
                    }
                    if (++attempts >= 3)
                    {   System.out.println("Too many attempts. Please register.");
                        new Register().register();
                        break;
                    }
                }
            }
            case 2 ->
            {
                String email = checkEmail();
                attempts = 0;
                while (true)
                {
                    System.out.print("Enter password: ");
                    password = scanner.next();
                    if (password.length() >= 6)
                    {
                        boolean ok = false;
                        try (Connection con = DB.get())
                        {
                            PreparedStatement pst; ResultSet rs;
                            if (x == 1)
                            {
                                pst = con.prepareStatement("SELECT u_id, u_name, u_password FROM user_details WHERE u_email=?");
                                pst.setString(1, email);
                                rs = pst.executeQuery();
                                if (rs.next() && rs.getString("u_password").equals(password))
                                {
                                    ok = true;
                                    int uid = rs.getInt("u_id");
                                    String uname = rs.getString("u_name");
                                    new User(uid, uname).menu();
                                }
                            }
                            else if (x == 2)
                            {
                                pst = con.prepareStatement("SELECT restaurantId, restaurantName, r_pass FROM restaurant WHERE r_email=?");
                                pst.setString(1, email);
                                rs = pst.executeQuery();
                                if (rs.next() && rs.getString("r_pass").equals(password))
                                {
                                    ok = true;
                                    int rid = rs.getInt("restaurantId");
                                    new Restaurant().WhattoDo(rid);
                                }
                            }
                            else if (x == 3)
                            {
                                pst = con.prepareStatement("SELECT dp_id, dp_name, dp_password FROM deliverypartner_details WHERE dp_email=?");
                                pst.setString(1, email);
                                rs = pst.executeQuery();
                                if (rs.next() && rs.getString("dp_password").equals(password))
                                {
                                    ok = true;
                                    int dpid= rs.getInt("dp_id");
                                    String dpname= rs.getString("dp_name");
                                    dpDetails(dpid,dpname);
                                    //System.out.println("Login success. Welcome, " + rs.getString("dp_name") + ".");
                                }
                            }
                        }
                        if (ok)
                        {
                            break;
                        }
                        else
                        {
                            System.out.println("Invalid credentials. Try again.");
                        }
                    }
                    else
                    {
                        System.out.println("Password must be at least 6 characters.");
                    }
                    if (++attempts >= 3)
                    {
                        System.out.println("Too many attempts. Please register.");
                        new Register().register();
                        break;
                    }
                }
            }
            default -> System.out.println("Enter Valid Choice.");
        }
    }

    protected String checkEmail()
    {
        while (true)
        {
            System.out.print("Email (@gmail.com/@yahoo.com): ");
            String email = scanner.next();
            if (email.length() >= 12 && email.length() <= 30)
            {
                String suffix = email.substring(email.length() - 10);
                if (suffix.equals("@gmail.com") || suffix.equals("@yahoo.com"))
                {
                    return email;
                }
                System.out.println("Email must end with @gmail.com or @yahoo.com.");
            }
            else
            {
                System.out.println("Email length must be between 12 and 30.");
            }
        }
    }

    protected long checkNumber()
    {
        while (true)
        {
            System.out.print("Enter 10-digit Mobile Number: ");
            String number = scanner.next();
            if (number.matches("\\d{10}"))
            {
                return Long.parseLong(number);
            }
            System.out.println("Enter a valid 10-digit mobile number.");
        }
    }
    void dpDetails(int id,String name) throws Exception
    {
        Connection con = DB.get();
        System.out.println("Login Successful.Welcome "+name+".\nHere is your orders details:");
        String q1="SELECT item_name,restaurantName,u_name FROM orders INNER JOIN order_items ON orders.order_id = order_items.order_id INNER JOIN restaurant ON orders.restaurant_id = restaurant.restaurantId INNER JOIN user_details ON orders.user_id = user_details.u_id WHERE delivery_partner_id = ?";
        PreparedStatement pst= con.prepareStatement(q1);
        pst.setInt(1,id);
        ResultSet rs= pst.executeQuery();
        while (rs.next())
        {
            System.out.println("You delivered "+rs.getString("item_name")+" from "+rs.getString("restaurantName")+" to "+rs.getString("u_name")+".");
        }
    }
}