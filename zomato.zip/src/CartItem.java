public class CartItem
{
    int itemId;
    String itemName;
    double price;
    int qty;

    public CartItem(int itemId, String itemName, double price, int qty)
    {
        this.itemId = itemId;
        this.itemName = itemName;
        this.price = price;
        this.qty = qty;
    }
}