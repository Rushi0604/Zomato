import java.util.Scanner;

public class Main
{
    public static void main(String[] args) throws Exception
    {
        Scanner scanner = new Scanner(System.in);
        Register register = new Register();
        Login login = new Login();
        int x;
        do
        {
            System.out.println("\n===== Welcome to FoodExpress =====");
            System.out.println("1) Register");
            System.out.println("2) Login");
            System.out.println("3) Admin");
            System.out.println("4) Exit");
            System.out.print("Choice: ");
            while (!scanner.hasNextInt())
            {
                System.out.print("Enter number: ");
                scanner.next();
            }
            x = scanner.nextInt();
            switch (x)
            {
                case 1 -> register.register();
                case 2 -> login.Login();
                case 3 ->
                {
                    AdminMenu admin = new AdminMenu();
                    admin.showMenu();
                }

                case 4 ->
                {
                    System.out.println("Exiting..!");
                    System.exit(0);
                }
                default -> System.out.println("Enter Valid Input");
            }
        } while (x != 4);
    }
}