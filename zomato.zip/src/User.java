import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class User
{
    Scanner sc = new Scanner(System.in);
    private final int userId;
    private final String userName;

    public User()
    {
        this.userId = -1;
        this.userName = "User";
    }
    public User(int userId, String userName)
    {
        this.userId = userId;
        this.userName = userName;
    }

    public void menu() throws Exception
    {
        try (Connection con = DB.get())
        {
            System.out.println("Do you want to order something?\n1) Yes\n2) No");
            System.out.print("Choice: ");
            int choice = readInt();
            if (choice == 2)
            {
                System.out.println("Exiting..!");
                return;
            }
            boolean breaks=true;
            while (breaks)
            {

                System.out.println("1.Order By Food Type\n2.Order By Restaurant Name\n3.See All Restaurant\n4.See All Food\n5.For Order");
                System.out.print("Choice: ");
                int x = readInt();
                switch (x)
                {
                    case 1:
                        String q1 = "SELECT restaurantId, restaurantName,item_name FROM restaurant JOIN menu_item on restaurant.restaurantId=menu_item.r_id where restaurantType=?";
                        System.out.print("Enter Food Type :");
                        PreparedStatement pst = con.prepareStatement(q1);
                        pst.setString(1, sc.next());
                        ResultSet rs = pst.executeQuery();
                        if(rs==null)
                        {
                            System.out.println("Food Type Not Found");
                        }
                        while (rs.next())
                        {
                            System.out.println(rs.getInt(1) + ") " + rs.getString(3));
                        }
                        break;

                    case 2:

                        String q2 = "SELECT restaurantId, restaurantName,item_name FROM restaurant JOIN menu_item on restaurant.restaurantId=menu_item.r_id WHERE restaurantname=?";
                        PreparedStatement pst1 = con.prepareStatement(q2);
                        System.out.print("Enter Restaurant Name: ");
                        pst1.setString(1, sc.next());
                        ResultSet rs1 = pst1.executeQuery();
                        if(rs1==null)
                        {
                            System.out.println("Restaurant Not Found");
                        }
                        while (rs1.next())
                        {
                            System.out.println(rs1.getInt(1) + ") " + rs1.getString(3));
                        }
                        break;

                    case 3:
                        String q3 = "SELECT restaurantId, restaurantName FROM restaurant";
                        PreparedStatement pst3 = con.prepareStatement(q3);
                        ResultSet rs3 = pst3.executeQuery();
                        while (rs3.next())
                        {
                            System.out.println(rs3.getInt(1) + ") " + rs3.getString(2));
                        }
                        break;

                    case 4:
                        String q4 = "SELECT r_Id,item_name FROM menu_item";
                        PreparedStatement pst4 = con.prepareStatement(q4);
                        ResultSet rs4 = pst4.executeQuery();
                    {
                        while (rs4.next())
                        {
                            System.out.println(rs4.getInt(1) + ") " + rs4.getString(2));
                        }
                    }
                    break;

                    case 5:
                        breaks=false;
                }
            }
            System.out.print("Enter restaurantId: ");
            int rId = readInt();

            String q2 = "SELECT item_id, item_name, price FROM menu_item WHERE r_id=?";
            Map<Integer, String> names = new HashMap<>();
            Map<Integer, Double> prices = new HashMap<>();

            try (PreparedStatement pst2 = con.prepareStatement(q2))
            {
                pst2.setInt(1, rId);
                try (ResultSet rs2 = pst2.executeQuery())
                {
                    System.out.println("\nMenu:");
                    while (rs2.next())
                    {
                        int iid = rs2.getInt("item_id");
                        String iname = rs2.getString("item_name");
                        double price = rs2.getDouble("price");
                        names.put(iid, iname);
                        prices.put(iid, price);
                        System.out.printf("%d) %s - %.2f Rs.%n", iid, iname, price);
                    }
                }
            }

            ArrayList<CartItem> cart = new ArrayList<>();
            while (true)
            {
                System.out.print("\nEnter item_id to add (0 to checkout): ");
                int iid = readInt();
                if (iid == 0)
                {
                    break;
                }
                if (!names.containsKey(iid))
                {
                    System.out.println("Invalid item_id.");
                    continue;
                }
                System.out.print("Quantity: ");
                int qty = Math.max(1, readInt());
                cart.add(new CartItem(iid, names.get(iid), prices.get(iid), qty));
                System.out.println("Added: " + names.get(iid) + " x" + qty);
            }

            if (cart.isEmpty())
            {
                System.out.println("Cart empty. Bye!");
                return;
            }

            double subTotal = 0.0;
            for (CartItem c : cart) subTotal += c.price * c.qty;
            double gst = subTotal * 0.05;
            double delivery = (subTotal >= 400) ? 0.0 : 40.0;
            double grand = subTotal + gst + delivery;

            printBill(rId, cart, subTotal, gst, delivery, grand);

            System.out.print("\nConfirm order? (1=Yes / 2=No): ");
            int ok = readInt();
            if (ok != 1)
            {
                System.out.println("Order cancelled.");
                return;
            }

            System.out.println("How would you like to make the payment? \n1) Cash \n2) Card \n3) Online");
            System.out.print("Choice: ");
            int pt = readInt();
            int r = 0;
            switch (pt)
            {
                case 1->
                {

                }
                case 2->
                {
                    r = creditcard(grand);
                }
                case 3->
                {
                    r = UPI(grand);
                }
            }
            if(r!=0)
            {
                if(pt==1)
                {
                    System.out.println("Pay "+grand+"Rs. to delivery partner");
                }
                int dpId = -1; String dpName = "Partner"; long dpNum = -1;
                try (PreparedStatement p = con.prepareStatement("SELECT dp_id, dp_name, dp_phoneNumber FROM deliverypartner_details ORDER BY RAND() LIMIT 1");
                     ResultSet rs = p.executeQuery())
                {
                    if (rs.next())
                    {
                        dpId = rs.getInt(1);
                        dpName = rs.getString(2);
                        dpNum = rs.getLong("dp_phoneNumber");
                    }
                }

                int eta = 20 + new java.util.Random().nextInt(16);
                System.out.println("\n📢 Your order will arrive in about " + eta + " minutes.");

                int orderId;
                try (PreparedStatement po = con.prepareStatement(
                        "INSERT INTO orders(user_id, restaurant_id, delivery_partner_id, eta_minutes, total_amount, status, created_at) VALUES (?,?,?,?,?, 'PREPARING', NOW())",
                        Statement.RETURN_GENERATED_KEYS))
                {
                    po.setInt(1, userId);
                    po.setInt(2, rId);
                    po.setInt(3, dpId);
                    po.setInt(4, eta);
                    po.setDouble(5, grand);
                    po.executeUpdate();
                    try (ResultSet keys = po.getGeneratedKeys())
                    {
                        keys.next();
                        orderId = keys.getInt(1);
                    }
                }

                try (PreparedStatement pi = con.prepareStatement(
                        "INSERT INTO order_items(order_id, item_id, item_name, price, qty) VALUES (?,?,?,?,?)")) {
                    for (CartItem c : cart) {
                        pi.setInt(1, orderId);
                        pi.setInt(2, c.itemId);
                        pi.setString(3, c.itemName);
                        pi.setDouble(4, c.price);
                        pi.setInt(5, c.qty);
                        pi.addBatch();
                    }
                    pi.executeBatch();
                }

                writeOrderToFile(userName, rId, cart, subTotal, gst, delivery, grand);

                OrderContext ctx = new OrderContext();
                ctx.orderId = orderId;
                ctx.restaurantId = rId;
                ctx.deliveryPartnerId = dpId;
                ctx.deliveryPartnerName = dpName;
                ctx.deliveryPartnerPhone = dpNum;
                ctx.etaMinutes = eta;
                Thread t = new Thread(new OrderProcessor(ctx));
                t.start();
            }
        }
    }

    private int readInt()
    {
        while (!sc.hasNextInt())
        {
            System.out.print("Enter number: ");
            sc.next();
        }
        return sc.nextInt();
    }

    private void printBill(int restaurantId, java.util.List<CartItem> cart, double subTotal, double gst, double delivery, double grand) throws SQLException
    {
        String rname = "Restaurant";
        try (Connection con = DB.get();
             PreparedStatement r = con.prepareStatement("SELECT restaurantName FROM restaurant WHERE restaurantId=?"))
        {
            r.setInt(1, restaurantId);
            try (ResultSet rs = r.executeQuery())
            {
                if (rs.next())
                {
                    rname = rs.getString(1);
                }
            }
        }
        System.out.println("\n=========== BILL ===========");
        System.out.println("Customer: " + userName);
        System.out.println("Restaurant: " + rname + " (ID: " + restaurantId + ")");
        System.out.println("----------------------------");
        for (CartItem c : cart)
        {
            System.out.printf("%-22s x%-2d  @ %.2f  = %.2f%n", c.itemName, c.qty, c.price, c.price * c.qty);
        }
        System.out.println("----------------------------");
        System.out.printf("Sub-Total:           %.2f%n", subTotal);
        System.out.printf("GST (5%%):            %.2f%n", gst);
        System.out.printf("Delivery:            %.2f%n", delivery);
        System.out.println("----------------------------");
        System.out.printf("GRAND TOTAL:         %.2f%n", grand);
        System.out.println("Time: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        System.out.println("============================\n");
    }
    private void writeOrderToFile(String userName, int rId, java.util.List<CartItem> cart,
                                  double subTotal, double gst, double delivery, double grand) throws SQLException
    {
        String rname = "Restaurant";
        try (Connection con = DB.get();
             PreparedStatement r = con.prepareStatement("SELECT restaurantName FROM restaurant WHERE restaurantId=?"))
        {
            r.setInt(1, rId);
            try (ResultSet rs = r.executeQuery())
            {
                if (rs.next()) rname = rs.getString(1);
            }
        }


        String safeName = rname.replaceAll("[^a-zA-Z0-9]", "_");
        File folder = new File("orders");
        if (!folder.exists())
        {
            folder.mkdir();
        }


        File f = new File(folder, safeName + ".txt");

        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        try (FileWriter fw = new FileWriter(f, true))
        {
            fw.write("================= ORDER =================\n");
            fw.write("User: " + userName + "\n");
            fw.write("Restaurant: " + rname + " (ID: " + rId + ")\n");
            for (CartItem c : cart)
            {
                fw.write(String.format("- %s x%d @ %.2f = %.2f%n",
                        c.itemName, c.qty, c.price, c.price * c.qty));
            }
            fw.write(String.format("SubTotal: %.2f | GST: %.2f | Delivery: %.2f | Total: %.2f%n",
                    subTotal, gst, delivery, grand));
            fw.write("Timestamp: " + ts + "\n");
            fw.write("==========================================\n\n");
        }
        catch (IOException e)
        {
            System.out.println("Failed to write order file: " + e.getMessage());
        }
    }
    private int  creditcard(double total)throws Exception   //Method for debit card payment
    {
        while(true)
        {
            System.out.println();
            System.out.print("Enter Credit Card Number (16 digits) : ");
            String creditnum = sc.next();
            if(creditnum.matches("\\d{16}"));
            {
                System.out.print("Enter Expiry Year : ");
                int year = sc.nextInt();
                Long cnum=Long.parseLong(creditnum);
                if(year>=2025)
                {
                    System.out.print("Enter Expiry Month : ");
                    int month = sc.nextInt();
                    if(month>=1&& month<=12)
                    {
                        if(month>=8)
                        {
                            int cvv = cheakcvv();
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
                            String sql="SELECT * FROM accounts WHERE cnum=? AND cvv=?";
                            PreparedStatement pst=con1.prepareStatement(sql);
                            pst.setLong(1,cnum);
                            pst.setInt(2,cvv);
                            ResultSet rs = pst.executeQuery();
                            if(rs==null)
                            {
                                System.out.println("Enter Valid Details");
                            }
                            while (rs.next())
                            {
                                int account_id=rs.getInt("a_id");
                                if(cnum.equals(rs.getLong("cnum")) && cvv==(rs.getInt("cvv")))
                                {
                                    if(rs.getInt("balance")>total)
                                    {
                                        String decrement = "UPDATE TABLE accounts SET balance=? WHERE a_id=?";
                                        PreparedStatement pst1 = con1.prepareStatement(decrement);
                                        pst1.setDouble(1,rs.getInt("balance")-total);
                                        pst1.setInt(2,account_id);
                                        pst1.executeUpdate();
                                        return 1;
                                    }
                                    else
                                    {
                                        System.out.println("You don't have money first earn money");
                                        return 0;
                                    }
                                }
                            }
                        }
                        else
                        {
                            System.out.println("Your Card has been Expaired !!");
                        }
                    }
                    else
                    {
                        System.out.println("Enter Valid Month !");
                    }
                }
                else
                {
                    System.out.println("Your Card has been Expaired !!");
                }
            }
            System.out.println("Enter Valid Card Number");
        }
    }
    private int cheakcvv()           //Method to check cvv need
    {
        while(true)
        {
            System.out.print("Enter CVV Code (3 digits) : ");
            String cvv=sc.next();
            if(cvv.matches("\\d{3}"))
            {
                return Integer.parseInt(cvv);
            }
            else
            {
                System.out.println("Enter Valid CVV !");
            }
        }
    }
    private int  UPI(double total)throws SQLException//method for pay with UPI
    {
        while(true)
        {
            System.out.println();
            System.out.println("Enter UPI Id In Form Of XYZ@paytm");
            System.out.print("UPI ID : ");
            String eupi = sc.next();
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
            String sql="SELECT * FROM accounts WHERE upi=?";
            PreparedStatement pst=con1.prepareStatement(sql);
            pst.setString(1,eupi);
            ResultSet rs = pst.executeQuery();
            if(rs==null)
            {
                System.out.println("Enter Valid UPI");
            }
            else
            {
                while (rs.next())
                {
                    int account_id=rs.getInt("a_id");
                    if(rs.getInt("balance")>total)
                    {
                        String decrement = "UPDATE TABLE accounts SET balance=? WHERE a_id=?";
                        PreparedStatement pst1 = con1.prepareStatement(decrement);
                        pst1.setDouble(1,rs.getInt("balance")-total);
                        pst1.setInt(2,account_id);
                        pst1.executeUpdate();
                        return 1;
                    }
                    else
                    {
                        System.out.println("You don't have money first earn money");
                        return 0;
                    }
                }
            }
        }
    }
}