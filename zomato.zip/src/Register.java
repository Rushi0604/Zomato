import java.util.*;
import java.sql.*;

public class Register
{
    protected String email ;
    protected String number ;
    Scanner scanner = new Scanner(System.in);

    protected void register() throws Exception
    {
        System.out.println("Hello Sir/Mam");
        System.out.println("1) user\n2) hotel\n3) delivery partner");
        System.out.print("choice : ");
        int x = readInt();
        System.out.print("Enter Your Name : ");
        String name = scanner.next();
        register(name, x);
    }

    private int readInt()
    {
        while (!scanner.hasNextInt())
        {
            System.out.print("Enter number: ");
            scanner.next();
        }
        return scanner.nextInt();

    }

    protected void register(String name, int x) throws SQLException
    {
        String email = emailcheck();
        String number = checkNumber();
        if (x == 1)
        {
            while (true)
            {
                System.out.print("Enter Password (min 6 letters One Upper case & One special character): ");
                String password = scanner.next();
                boolean b = checkPassword(password);
                if(b)
                {
                    System.out.print("Enter Address:");
                    String address=scanner.next();
                    try (Connection con = DB.get();
                         PreparedStatement pst = con.prepareStatement(
                                 "INSERT INTO user_details(u_name, u_email, u_phoneNumber,u_address, u_password) VALUES (?,?,?,?,?)"))
                    {
                        pst.setString(1, name);
                        pst.setString(2, email);
                        pst.setString(3, number);
                        pst.setString(4, address);
                        pst.setString(5,password);
                        int r = pst.executeUpdate();
                        System.out.println(r > 0 ? "Successfully Registered" : "Registration Failed");
                    }
                    return;
                }
                else
                {
                    System.out.println("Password invalid.!");
                }
            }
        }
        else if (x == 2)
        {
            System.out.print("Enter Hotel Type : ");
            String type = scanner.next();
            System.out.print("Enter Hotel Address : ");
            String address = scanner.next();
            while (true)
            {
                System.out.print("Enter Password (min 6 letters One Upper case & One special character): ");
                String password = scanner.next();
                boolean b =checkPassword(password);
                if (b)
                {
                    try (Connection con = DB.get();
                         PreparedStatement pst = con.prepareStatement(
                                 "INSERT INTO restaurant(restaurantName, r_email, restaurantPhone, r_pass, r_type, r_address) VALUES (?,?,?,?,?,?)")) {
                        pst.setString(1, name);
                        pst.setString(2, email);
                        pst.setString(3, number);
                        pst.setString(4, password);
                        pst.setString(5, type);
                        pst.setString(6, address);
                        int r = pst.executeUpdate();
                        System.out.println(r > 0 ? "Successfully Registered" : "Registration Failed");
                    }
                    return;
                }
                else
                {
                    System.out.println("Password Invalid.!");
                }
            }
        }
        else if (x == 3)
        {
            while (true)
            {
                System.out.print("Enter Password (min 6 letters One Upper case & One special character): ");
                String password = scanner.next();
                boolean b=checkPassword(password);
                if (b)
                {
                    try (Connection con = DB.get();
                         PreparedStatement pst = con.prepareStatement(
                                 "INSERT INTO deliverypartner_details(dp_name, dp_email, dp_phoneNumber, dp_password) VALUES (?,?,?,?)")) {
                        pst.setString(1, name);
                        pst.setString(2, email);
                        pst.setString(3, number);
                        pst.setString(4, password);
                        int r = pst.executeUpdate();
                        System.out.println(r > 0 ? "Successfully Registered" : "Registration Failed");
                    }
                    return;
                }
                else
                {
                    System.out.println("Password Invalid.!");
                }
            }
        }
    }

    protected String emailcheck()
    {
        scanner.nextLine();
        while (true)
        {
            System.out.print("Email (@gmail.com/@yahoo.com): ");
            email = scanner.nextLine();
            if (email.length() >= 12 && email.length() <= 30)
            {
                String suf = email.substring(email.length() - 10);
                if (suf.equals("@gmail.com") || suf.equals("@yahoo.com"))
                {
                    return email;
                }
                else
                {
                    System.out.println("Enter Valid Email domain.");
                }
            }
            else
            {
                System.out.println("Enter Valid Email length (<=30).");
            }
        }
    }

    protected String checkNumber()
    {
        while (true)
        {
            System.out.print("Enter Mobile Number : ");
            number = scanner.next();
            if (number.matches("\\d{10}"))
            {
                return number;
            }
            System.out.println("Enter valid 10-digit number");
        }
    }
    public static boolean checkPassword(String password)
    {
        // condition 1: length check
        if (password.length() < 6)
        {
            return false;
        }

        boolean hasUpper = false;
        boolean hasSpecial = false;

        // loop through each character
        for (char ch : password.toCharArray())
        {
            if (Character.isUpperCase(ch))
            {
                hasUpper = true;
            }
            // special char check (not letter or digit)
            else if (!Character.isLetterOrDigit(ch))
            {
                hasSpecial = true;
            }
        }

        // return true only if all conditions are met
        return hasUpper && hasSpecial;
    }
}