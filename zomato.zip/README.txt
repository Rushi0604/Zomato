FoodExpress Project (Java + MySQL)

How to run:
1) Import MySQL JDBC driver in your IDE or classpath.
2) Edit DB.java (URL/USER/PASS) to match your MySQL.
3) Run the SQL script in db/schema.sql in your MySQL (after you have your existing tables for restaurant, user_details, menu_item, deliverypartner_details).
4) Compile all Java files in src/ and run Main.java.
5) Place order to see: cart -> detailed bill -> DB inserts -> order.txt created -> simulated delivery with threads.

Notes:
- order.txt is created in the working directory.
- Triggers write to order_audit/menu_audit.
- Free delivery for orders >= 400; GST is 5%.